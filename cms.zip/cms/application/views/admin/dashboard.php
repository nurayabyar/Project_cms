<h1>Selamat datang di halaman Dashboard</h1>
<?= $this->session->userdata('nama'); ?>