<!doctype html>
<html lang="en">

<d>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title> <?= $konfig->judul_website; ?></title>

  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/front/'); ?> css/vendor.css">
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">


  <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.css" />


  <!-- Link Bootstrap's CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

  <link rel="stylesheet" href="<?= base_url('assets/front/'); ?>style.css">

  <!-- Google Fonts ================================================== -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@300;400;500;600;700&display=swap"
    rel="stylesheet">

  <!-- script ================================================== -->
  <script src="<?= base_url('assets/front/'); ?>js/modernizr.js"></script>
  <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
  <style>
    /* Menentukan ukuran tetap untuk semua gambar di dalam card */
      .fixed-img {
          width: 100%;               /* Mengikuti lebar parent */
          height: 250px;             /* Tinggi gambar tetap */
          object-fit: cover;         /* Memastikan gambar di-crop tanpa distorsi */
          object-position: center;   /* Fokus crop pada bagian tengah */
          border-radius: 5px;        /* Opsional: Menambahkan radius pada sudut gambar */
      }

      /* Menambahkan style tambahan untuk responsif */
      @media (max-width: 768px) {
        .fixed-img {
          height: 200px; /* Mengurangi tinggi gambar di layar kecil */
        }
      }

      .residence-swiper .card {
          box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Tambahkan shadow untuk estetika */
          border: none; /* Hilangkan border default */
      }

      /* Ukuran Tetap untuk Semua Gambar */
      .fixed-testimonial-img {
          width: 100%;               /* Gambar mengikuti lebar parent */
          height: 400px;             /* Tinggi gambar tetap */
          object-fit: cover;         /* Memastikan gambar tetap proporsional */
          object-position: center;   /* Fokus gambar di tengah */
          border-radius: 8px;        /* Opsional: Tambahkan sudut melengkung */
      }

      /* Responsif untuk Layar Kecil */
      @media (max-width: 768px) {
        .fixed-testimonial-img {
          height: 250px; /* Kurangi tinggi gambar pada layar kecil */
        }
      }

      /* Styling Navigasi */
      .testimonial-swiper-button {
          top: 50%;                   /* Posisi di tengah vertikal */
          display: flex;              /* Menjadikan elemen horizontal */
          justify-content: space-between;
          align-items: center;
          transform: translateY(-50%); /* Menyesuaikan posisi vertikal */
          z-index: 10;                /* Navigasi berada di atas slider */
      }

      .testimonial-arrow {
          font-size: 24px;
          color: #333;                /* Warna panah */
          cursor: pointer;
      }

      .arrow-divider {
          margin: 0 10px;
          color: #aaa;                /* Warna pemisah */
          font-weight: bold;
      }


  </style>
</head>

<body data-bs-spy="scroll" data-bs-target="#navbar-example2" tabindex="0">

  <!-- nav bar start  -->
  <header id="nav" class="site-header position-fixed text-white bg-dark">
    <nav id="navbar-example2" class="navbar navbar-expand-lg py-2">
      <div class="container ">
        <a class="navbar-brand" href="./index.html">
          <img src="<?= base_url('assets/front/'); ?>images/logorara.webp" alt="image"
            style="width: 50px; height: auto;">
          <?= $konfig->judul_website; ?>
        </a>

        <button class="navbar-toggler text-white" type="button" data-bs-toggle="offcanvas"
          data-bs-target="#offcanvasNavbar2" aria-controls="offcanvasNavbar2" aria-label="Toggle navigation"><ion-icon
            name="menu-outline" style="font-size: 30px;"></ion-icon></button>
        <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasNavbar2"
          aria-labelledby="offcanvasNavbar2Label">
          <div class="offcanvas-body">
            <ul class="navbar-nav align-items-center justify-content-end align-items-center flex-grow-1 ">
              <li class="nav-item">
                <a class="nav-link active me-md-4" href="<?= base_url() ?>">Home</a>
              </li>
              <?php foreach ($kategori as $kate) { ?>
                <a class="nav-link me-md-4" href="<?= base_url('home/kategori/' . $kate['id_kategori']) ?>">
                  <?= $kate['nama_kategori'] ?>
                </a>
              <?php } ?>
              <li class="nav-item">
                <a class="nav-link mx-md-4" href="<?= base_url('auth') ?>">Login</a>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
  </header>

  <!-- billboard start  -->
  <section id="billboard">
    <div class="container ">
      <div class="row flex-lg-row-reverse align-items-center ">

        <div class="col-lg-6">
          <img src="<?= base_url('assets/front/'); ?>images/rumah2.jpg" class="d-block mx-lg-auto img-fluid"
            alt="Bootstrap Themes" width="700" height="500" loading="lazy">
        </div>

        <div class="col-lg-6">
          <h3>Selamat Datang Di <?= $konfig->judul_website; ?></h3>
          <h1 class=" text-capitalize  lh-1 my-3">Cara Terbaik untuk Membeli Rumah</h1>
          <p class="lead">Nikmati suasana nyaman, asri, dan strategis
            dengan fasilitas lengkap seperti taman bermain, area olahraga, dan keamanan 24 jam.</p>
        </div>
      </div>
    </div>
  </section>

  <!--About us start  -->
  <section id="about-us">
    <div class="container">
      <div class="row py-lg-5">

        <h2 class="text-capitalize text-center m-0 py-lg-5">Kenapa harus <?= $konfig->judul_website; ?> ?</h2>

        <div class="text-center col-lg-4">
          <img src="<?= base_url('assets/front/'); ?>images/search.png" class="bd-placeholder-img rounded-circle" alt="Bootstrap Themes" width="140"
            height="140" loading="lazy">
          <h3 class="fw-normal mt-5 ">MUDAH DICARI</h>
        </div>

        <div class="text-center col-lg-4">
          <img src="<?= base_url('assets/front/'); ?>images/price.png" class="bd-placeholder-img rounded-circle" alt="Bootstrap Themes" width="140"
            height="140" loading="lazy">
          <h3 class="fw-normal mt-5">HARGA TERJANGKAU</h3>
        </div>

        <div class="text-center col-lg-4">
          <img src="<?= base_url('assets/front/'); ?>images/time.png" class="bd-placeholder-img rounded-circle" alt="Bootstrap Themes" width="140"
            height="140" loading="lazy">
          <h3 class="fw-normal mt-5 ">PROSES CEPAT</h3>
        </div>
      </div>
    </div>
  </section>

  <!-- Residence start  -->
  <section id="residence">
  <div class="container my-5 py-5">
    <h2 class="text-capitalize m-0 py-lg-5">Residensi Populer</h2>

    <!-- Arrow Navigation -->
    <div class="swiper-button-next residence-swiper-next"></div>
    <div class="swiper-button-prev residence-swiper-prev"></div>

    <!-- Swiper Wrapper -->
    <div class="swiper residence-swiper">
      <div class="swiper-wrapper">
        <?php $no = 1;
        foreach ($konten as $uu) { ?>
          <div class="swiper-slide">
            <div class="card h-100">
              <a href="index.html">
                <img src="<?= site_url('assets/upload/konten/') . $uu['foto']; ?>" 
                     class="card-img-top fixed-img" alt="image">
              </a>
              <div class="card-body p-0">
                <a href="index.html">
                  <h5 class="card-title pt-4 text-center"><?= $uu['judul'] ?></h5>
                </a>
                <p class="card-text text-center"><?= $uu['keterangan'] ?></p>
                <div class="card-text">
                  <h5>Fasilitas</h5>
                  <ul class="d-flex justify-content-between px-2">
                    <li class="residence-list">
                      <img src="<?= base_url('assets/front/'); ?>images/bed.png" alt="image">
                      <?= $uu['kasur'] ?>
                    </li>
                    <li class="residence-list">
                      <img src="<?= base_url('assets/front/'); ?>images/bath.png" alt="image">
                      <?= $uu['toilet'] ?>
                    </li>
                    <li class="residence-list">
                      <img src="<?= base_url('assets/front/'); ?>images/square.png" alt="image">
                      <?= $uu['luas'] ?> M
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        <?php $no++;
        } ?>
      </div>
    </div>
  </div>
</section>


  <!-- Testimonial start  -->
  <section id="testimonial">
  <div class="container my-5">
    <!-- Static Text in Center -->
    <div class="text-overlay">
      <h2 class="text-capitalize text-center m-0 py-lg-5">Terjual 600+ unit</h3>
    </div>
    <!-- Swiper Container -->
    <div class="swiper testimonial-swiper">
      <div class="swiper-wrapper">
        <?php foreach ($konten as $uu) { ?>
          <div class="swiper-slide">
            <div class="row my-5 py-lg-5">
              <div class="col-md-8 mx-auto">
                <img src="<?= site_url('assets/upload/konten/') . $uu['foto']; ?>" class="card-img-top" alt="image">
              </div>
            </div>
          </div>
        <?php } ?>
      </div>
      <!-- Navigation Buttons -->
      <div class="testimonial-swiper-button col-md-3 position-absolute">
        <div class="swiper-button-prev testimonial-arrow"></div>
        <div class="arrow-divider"> | </div>
        <div class="swiper-button-next testimonial-arrow"></div>
      </div>
    </div>
  </div>
</section>


  <!-- Help start  -->
  <section id="help" class="py-5"
    style="background: linear-gradient(270deg, #1A242F 0.01%, rgba(26, 36, 47, 0.00) 100%);">
    <div class="container-lg my-5">

      <div class="row d-flex justify-content-between align-items-center">

        <div class="col-md-6">
          <div class="image-holder d-flex">
            <img src="<?= base_url('assets/front/'); ?>images/rm.jpg" class="img-fluid" alt="Bootstrap Themes" loading="lazy">
          </div>
        </div>

        <div class="col-md-6">
          <div class="text-content ps-md-5 mt-4 mt-md-0">
            <h2 class="text-capitalize">Kami membantu orang menemukan rumah impian.</h2>
            <p>Kami berkomitmen untuk membantu setiap orang menemukan rumah impian mereka, 
              tempat di mana mereka dapat merasa nyaman, aman, dan membangun masa depan yang lebih baik..</p>
              <a href="https://wa.me/6281228975477?text=Halo%20kami%20ingin%20bertanya%20tentang%20rumah%20impian" 
                class="btn btn-primary btn-lg" 
                target="_blank" 
                rel="noopener noreferrer">
                Hubungi Kami
              </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- Footer start  -->
  <section id="footer">
  <div class="container footer-container">
    <footer class="row row-cols-1 row-cols-sm-2 row-cols-md-5 justify-content-center">
      <div class="col-md-4">
        <h3>
          <img src="<?= base_url('assets/front/'); ?>images/logorara.webp" alt="image"
            style="width: 50px; height: auto;">
          <?= $konfig->judul_website; ?>
        </h3>
        <p><?= $konfig->profil_website; ?></p>
        <?php if (!empty($konfig->instagram)): ?>
          <a href="<?= $konfig->instagram; ?>" target="_blank">
            <i class="bi bi-instagram pe-4"></i>
          </a>
        <?php endif; ?>
        <?php if (!empty($konfig->twiter)): ?>
          <a href="<?= $konfig->twiter; ?>" target="_blank">
            <i class="bi bi-twitter pe-4"></i>
          </a>
        <?php endif; ?>
        <?php if (!empty($konfig->youtube)): ?>
          <a href="<?= $konfig->youtube; ?>" target="_blank">
            <i class="bi bi-youtube pe-4"></i>
          </a>
        <?php endif; ?>
      </div>

      <!-- Bagian Alamat, Email, dan Nomor Telepon -->
      <div class="col-lg-4 col-md-4 ">
        <div class="nav flex-column">
          <h5 class="spacing-lg">Alamat</h5>
          <p class="nav-item mb-4"><?= $konfig->alamat; ?></p>

          <h5 class="spacing-lg">Email</h5>
          <p class="nav-item mb-4"><?= $konfig->email; ?></p>

          <h5 class="spacing-lg">Nomor Telepon</h5>
          <p class="nav-item mb-4">+<?= $konfig->no_wa; ?></p>
        </div>
      </div>
    </footer>
  </div>

  <!-- Footer Copyright -->
  <div class="container">
    <footer class="d-flex flex-wrap justify-content-center align-items-center py-2 border-top">
      <p class="text-center mb-0">&copy; <?= date('Y'); ?> <?= $konfig->judul_website; ?>. All rights reserved.</p>
    </footer>
  </div>
</section>



  <script src="<?= base_url('assets/front/'); ?>js/jquery-1.11.0.min.js"></script>
  <script src="<?= base_url('assets/front/'); ?>js/script.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@9/swiper-bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4"
    crossorigin="anonymous"></script>
</body>

</html>