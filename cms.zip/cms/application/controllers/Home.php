<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    public function __construct(){
        parent::__construct();
    }
	public function index()
	{
		$this->db->from('konfigurasi');
		$konfig = $this->db->get()->row();
		$this->db->from('caraousel');
		$caraousel = $this->db->get()->result_array();
		$this->db->from('kategori');
		$kategori = $this->db->get()->result_array();
		$this->db->from('konten a');
        $this->db->join('kategori b','a.id_kategori=b.id_kategori', 'left');
        $this->db->join('user c','a.username=c.username', 'left');
        $this->db->order_by('tanggal', 'DESC');
        $konten = $this->db->get()->result_array(); 
		$data = array(
			'judul'			=> "Beranda | Rara",
			'konfig'		=> $konfig,
			'kategori'		=> $kategori,
			'caraousel'		=> $caraousel,
			'konten'		=> $konten,
		);
		$this->load->view('beranda', $data);
	}

	public function kategori($id){
		$this->db->from('konfigurasi');
		$konfig = $this->db->get()->row();
		$this->db->from('caraousel');
		$caraousel = $this->db->get()->result_array();
		$this->db->from('kategori');
		$kategori = $this->db->get()->result_array();
		$this->db->from('konten a');
		$this->db->join('kategori b','a.id_kategori=b.id_kategori', 'left');
		$this->db->join('user c','a.username=c.username', 'left');
		$this->db->where('a.id_kategori', $id);
		$konten = $this->db->get()->result_array(); 
	
		// Modify the 'judul' assignment as it's now part of an array
		$judul = (count($konten) > 0) ? $konten[0]['judul'] : 'No title available'; // Use the first element or set a default value if no results
		
		$data = array(            
			'judul'         => $judul . " | Rara",  // Corrected this line
			'konfig'        => $konfig,
			'kategori'      => $kategori,
			'konten'        => $konten,
		);
		$this->load->view('detail', $data);
	}
	
}
 